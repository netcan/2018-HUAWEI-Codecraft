/****************************************************************************
 > File Name: random.cpp
 > Author: Netcan
 > Blog: http://www.netcan666.com/
 > Mail: netcan1996@gmail.com
 > Created Time: 2018-03-20 -- 11:07
 ****************************************************************************/

#include "random.h"

Random Rand;
